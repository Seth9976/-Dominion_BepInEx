﻿using System;

// Token: 0x020000CF RID: 207
public enum AN_CameraCaptureType
{
	// Token: 0x04000B6B RID: 2923
	Thumbnail,
	// Token: 0x04000B6C RID: 2924
	FullSizePhoto
}
