﻿using System;

// Token: 0x02000003 RID: 3
public enum SA_PD_MessageType
{
	// Token: 0x04000004 RID: 4
	None,
	// Token: 0x04000005 RID: 5
	Info,
	// Token: 0x04000006 RID: 6
	Warning,
	// Token: 0x04000007 RID: 7
	Error
}
