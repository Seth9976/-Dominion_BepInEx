﻿using System;

// Token: 0x0200006F RID: 111
public enum GP_TBM_MatchesSortOrder
{
	// Token: 0x040006BE RID: 1726
	SORT_ORDER_MOST_RECENT_FIRST,
	// Token: 0x040006BF RID: 1727
	SORT_ORDER_SOCIAL_AGGREGATION
}
