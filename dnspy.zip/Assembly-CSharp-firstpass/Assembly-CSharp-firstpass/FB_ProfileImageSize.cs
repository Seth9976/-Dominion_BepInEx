﻿using System;

// Token: 0x02000096 RID: 150
public enum FB_ProfileImageSize
{
	// Token: 0x040008A6 RID: 2214
	large,
	// Token: 0x040008A7 RID: 2215
	normal,
	// Token: 0x040008A8 RID: 2216
	small,
	// Token: 0x040008A9 RID: 2217
	square
}
