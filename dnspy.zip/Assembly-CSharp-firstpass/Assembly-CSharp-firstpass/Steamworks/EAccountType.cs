﻿using System;

namespace Steamworks
{
	// Token: 0x02000286 RID: 646
	public enum EAccountType
	{
		// Token: 0x04002484 RID: 9348
		k_EAccountTypeInvalid,
		// Token: 0x04002485 RID: 9349
		k_EAccountTypeIndividual,
		// Token: 0x04002486 RID: 9350
		k_EAccountTypeMultiseat,
		// Token: 0x04002487 RID: 9351
		k_EAccountTypeGameServer,
		// Token: 0x04002488 RID: 9352
		k_EAccountTypeAnonGameServer,
		// Token: 0x04002489 RID: 9353
		k_EAccountTypePending,
		// Token: 0x0400248A RID: 9354
		k_EAccountTypeContentServer,
		// Token: 0x0400248B RID: 9355
		k_EAccountTypeClan,
		// Token: 0x0400248C RID: 9356
		k_EAccountTypeChat,
		// Token: 0x0400248D RID: 9357
		k_EAccountTypeConsoleUser,
		// Token: 0x0400248E RID: 9358
		k_EAccountTypeAnonUser,
		// Token: 0x0400248F RID: 9359
		k_EAccountTypeMax
	}
}
