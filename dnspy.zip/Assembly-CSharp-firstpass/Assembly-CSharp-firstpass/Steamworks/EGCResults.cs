﻿using System;

namespace Steamworks
{
	// Token: 0x0200024A RID: 586
	public enum EGCResults
	{
		// Token: 0x04002129 RID: 8489
		k_EGCResultOK,
		// Token: 0x0400212A RID: 8490
		k_EGCResultNoMessage,
		// Token: 0x0400212B RID: 8491
		k_EGCResultBufferTooSmall,
		// Token: 0x0400212C RID: 8492
		k_EGCResultNotLoggedOn,
		// Token: 0x0400212D RID: 8493
		k_EGCResultInvalidMessage
	}
}
