﻿using System;

namespace Steamworks
{
	// Token: 0x0200028D RID: 653
	[Flags]
	public enum EChatSteamIDInstanceFlags
	{
		// Token: 0x040024E6 RID: 9446
		k_EChatAccountInstanceMask = 4095,
		// Token: 0x040024E7 RID: 9447
		k_EChatInstanceFlagClan = 524288,
		// Token: 0x040024E8 RID: 9448
		k_EChatInstanceFlagLobby = 262144,
		// Token: 0x040024E9 RID: 9449
		k_EChatInstanceFlagMMSLobby = 131072
	}
}
