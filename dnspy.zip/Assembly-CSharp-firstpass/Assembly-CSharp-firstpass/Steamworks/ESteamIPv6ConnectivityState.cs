﻿using System;

namespace Steamworks
{
	// Token: 0x0200029A RID: 666
	public enum ESteamIPv6ConnectivityState
	{
		// Token: 0x0400257F RID: 9599
		k_ESteamIPv6ConnectivityState_Unknown,
		// Token: 0x04002580 RID: 9600
		k_ESteamIPv6ConnectivityState_Good,
		// Token: 0x04002581 RID: 9601
		k_ESteamIPv6ConnectivityState_Bad
	}
}
