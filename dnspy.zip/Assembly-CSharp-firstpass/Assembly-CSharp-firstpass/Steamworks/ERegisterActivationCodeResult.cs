﻿using System;

namespace Steamworks
{
	// Token: 0x02000240 RID: 576
	public enum ERegisterActivationCodeResult
	{
		// Token: 0x04001FE7 RID: 8167
		k_ERegisterActivationCodeResultOK,
		// Token: 0x04001FE8 RID: 8168
		k_ERegisterActivationCodeResultFail,
		// Token: 0x04001FE9 RID: 8169
		k_ERegisterActivationCodeResultAlreadyRegistered,
		// Token: 0x04001FEA RID: 8170
		k_ERegisterActivationCodeResultTimeout,
		// Token: 0x04001FEB RID: 8171
		k_ERegisterActivationCodeAlreadyOwned
	}
}
