﻿using System;

namespace Steamworks
{
	// Token: 0x0200027B RID: 635
	public enum EGamepadTextInputLineMode
	{
		// Token: 0x040023C6 RID: 9158
		k_EGamepadTextInputLineModeSingleLine,
		// Token: 0x040023C7 RID: 9159
		k_EGamepadTextInputLineModeMultipleLines
	}
}
