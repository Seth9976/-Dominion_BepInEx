﻿using System;

namespace Steamworks
{
	// Token: 0x02000243 RID: 579
	public enum EFriendRelationship
	{
		// Token: 0x040020E8 RID: 8424
		k_EFriendRelationshipNone,
		// Token: 0x040020E9 RID: 8425
		k_EFriendRelationshipBlocked,
		// Token: 0x040020EA RID: 8426
		k_EFriendRelationshipRequestRecipient,
		// Token: 0x040020EB RID: 8427
		k_EFriendRelationshipFriend,
		// Token: 0x040020EC RID: 8428
		k_EFriendRelationshipRequestInitiator,
		// Token: 0x040020ED RID: 8429
		k_EFriendRelationshipIgnored,
		// Token: 0x040020EE RID: 8430
		k_EFriendRelationshipIgnoredFriend,
		// Token: 0x040020EF RID: 8431
		k_EFriendRelationshipSuggested_DEPRECATED,
		// Token: 0x040020F0 RID: 8432
		k_EFriendRelationshipMax
	}
}
