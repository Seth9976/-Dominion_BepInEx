﻿using System;

namespace Steamworks
{
	// Token: 0x02000257 RID: 599
	public enum ELobbyDistanceFilter
	{
		// Token: 0x040022BF RID: 8895
		k_ELobbyDistanceFilterClose,
		// Token: 0x040022C0 RID: 8896
		k_ELobbyDistanceFilterDefault,
		// Token: 0x040022C1 RID: 8897
		k_ELobbyDistanceFilterFar,
		// Token: 0x040022C2 RID: 8898
		k_ELobbyDistanceFilterWorldwide
	}
}
