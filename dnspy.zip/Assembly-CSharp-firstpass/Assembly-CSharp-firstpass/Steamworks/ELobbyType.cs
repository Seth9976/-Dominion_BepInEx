﻿using System;

namespace Steamworks
{
	// Token: 0x02000255 RID: 597
	public enum ELobbyType
	{
		// Token: 0x040022B2 RID: 8882
		k_ELobbyTypePrivate,
		// Token: 0x040022B3 RID: 8883
		k_ELobbyTypeFriendsOnly,
		// Token: 0x040022B4 RID: 8884
		k_ELobbyTypePublic,
		// Token: 0x040022B5 RID: 8885
		k_ELobbyTypeInvisible,
		// Token: 0x040022B6 RID: 8886
		k_ELobbyTypePrivateUnique
	}
}
