﻿using System;

namespace Steamworks
{
	// Token: 0x0200025C RID: 604
	public enum AudioPlayback_Status
	{
		// Token: 0x040022D8 RID: 8920
		AudioPlayback_Undefined,
		// Token: 0x040022D9 RID: 8921
		AudioPlayback_Playing,
		// Token: 0x040022DA RID: 8922
		AudioPlayback_Paused,
		// Token: 0x040022DB RID: 8923
		AudioPlayback_Idle
	}
}
