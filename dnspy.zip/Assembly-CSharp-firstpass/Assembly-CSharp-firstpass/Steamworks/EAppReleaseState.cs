﻿using System;

namespace Steamworks
{
	// Token: 0x02000287 RID: 647
	public enum EAppReleaseState
	{
		// Token: 0x04002491 RID: 9361
		k_EAppReleaseState_Unknown,
		// Token: 0x04002492 RID: 9362
		k_EAppReleaseState_Unavailable,
		// Token: 0x04002493 RID: 9363
		k_EAppReleaseState_Prerelease,
		// Token: 0x04002494 RID: 9364
		k_EAppReleaseState_PreloadOnly,
		// Token: 0x04002495 RID: 9365
		k_EAppReleaseState_Released
	}
}
