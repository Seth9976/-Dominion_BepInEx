﻿using System;

namespace Steamworks
{
	// Token: 0x02000262 RID: 610
	public enum ESteamDeviceFormFactor
	{
		// Token: 0x04002309 RID: 8969
		k_ESteamDeviceFormFactorUnknown,
		// Token: 0x0400230A RID: 8970
		k_ESteamDeviceFormFactorPhone,
		// Token: 0x0400230B RID: 8971
		k_ESteamDeviceFormFactorTablet,
		// Token: 0x0400230C RID: 8972
		k_ESteamDeviceFormFactorComputer,
		// Token: 0x0400230D RID: 8973
		k_ESteamDeviceFormFactorTV
	}
}
