﻿using System;

namespace Steamworks
{
	// Token: 0x0200027F RID: 639
	public enum EServerMode
	{
		// Token: 0x040023D8 RID: 9176
		eServerModeInvalid,
		// Token: 0x040023D9 RID: 9177
		eServerModeNoAuthentication,
		// Token: 0x040023DA RID: 9178
		eServerModeAuthentication,
		// Token: 0x040023DB RID: 9179
		eServerModeAuthenticationAndSecure
	}
}
