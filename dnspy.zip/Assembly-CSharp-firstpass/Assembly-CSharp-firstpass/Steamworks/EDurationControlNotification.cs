﻿using System;

namespace Steamworks
{
	// Token: 0x02000295 RID: 661
	public enum EDurationControlNotification
	{
		// Token: 0x0400255D RID: 9565
		k_EDurationControlNotification_None,
		// Token: 0x0400255E RID: 9566
		k_EDurationControlNotification_1Hour,
		// Token: 0x0400255F RID: 9567
		k_EDurationControlNotification_3Hours,
		// Token: 0x04002560 RID: 9568
		k_EDurationControlNotification_HalfProgress,
		// Token: 0x04002561 RID: 9569
		k_EDurationControlNotification_NoProgress,
		// Token: 0x04002562 RID: 9570
		k_EDurationControlNotification_ExitSoon_3h,
		// Token: 0x04002563 RID: 9571
		k_EDurationControlNotification_ExitSoon_5h,
		// Token: 0x04002564 RID: 9572
		k_EDurationControlNotification_ExitSoon_Night
	}
}
