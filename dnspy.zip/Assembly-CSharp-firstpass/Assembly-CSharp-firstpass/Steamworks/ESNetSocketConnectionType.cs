﻿using System;

namespace Steamworks
{
	// Token: 0x02000260 RID: 608
	public enum ESNetSocketConnectionType
	{
		// Token: 0x040022F5 RID: 8949
		k_ESNetSocketConnectionTypeNotConnected,
		// Token: 0x040022F6 RID: 8950
		k_ESNetSocketConnectionTypeUDP,
		// Token: 0x040022F7 RID: 8951
		k_ESNetSocketConnectionTypeUDPRelay
	}
}
