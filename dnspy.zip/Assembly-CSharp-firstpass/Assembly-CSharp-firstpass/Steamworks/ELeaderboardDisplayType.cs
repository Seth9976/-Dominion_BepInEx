﻿using System;

namespace Steamworks
{
	// Token: 0x02000277 RID: 631
	public enum ELeaderboardDisplayType
	{
		// Token: 0x040023B4 RID: 9140
		k_ELeaderboardDisplayTypeNone,
		// Token: 0x040023B5 RID: 9141
		k_ELeaderboardDisplayTypeNumeric,
		// Token: 0x040023B6 RID: 9142
		k_ELeaderboardDisplayTypeTimeSeconds,
		// Token: 0x040023B7 RID: 9143
		k_ELeaderboardDisplayTypeTimeMilliSeconds
	}
}
