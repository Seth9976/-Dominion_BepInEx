﻿using System;

namespace Steamworks
{
	// Token: 0x02000274 RID: 628
	public enum EFailureType
	{
		// Token: 0x040023A8 RID: 9128
		k_EFailureFlushedCallbackQueue,
		// Token: 0x040023A9 RID: 9129
		k_EFailurePipeFail
	}
}
