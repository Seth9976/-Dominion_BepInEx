﻿using System;

namespace Steamworks
{
	// Token: 0x02000253 RID: 595
	public enum ESteamInputLEDFlag
	{
		// Token: 0x040022AB RID: 8875
		k_ESteamInputLEDFlag_SetColor,
		// Token: 0x040022AC RID: 8876
		k_ESteamInputLEDFlag_RestoreUserDefault
	}
}
