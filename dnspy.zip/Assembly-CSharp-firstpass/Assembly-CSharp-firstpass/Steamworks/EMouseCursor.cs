﻿using System;

namespace Steamworks
{
	// Token: 0x0200024C RID: 588
	public enum EMouseCursor
	{
		// Token: 0x04002133 RID: 8499
		dc_user,
		// Token: 0x04002134 RID: 8500
		dc_none,
		// Token: 0x04002135 RID: 8501
		dc_arrow,
		// Token: 0x04002136 RID: 8502
		dc_ibeam,
		// Token: 0x04002137 RID: 8503
		dc_hourglass,
		// Token: 0x04002138 RID: 8504
		dc_waitarrow,
		// Token: 0x04002139 RID: 8505
		dc_crosshair,
		// Token: 0x0400213A RID: 8506
		dc_up,
		// Token: 0x0400213B RID: 8507
		dc_sizenw,
		// Token: 0x0400213C RID: 8508
		dc_sizese,
		// Token: 0x0400213D RID: 8509
		dc_sizene,
		// Token: 0x0400213E RID: 8510
		dc_sizesw,
		// Token: 0x0400213F RID: 8511
		dc_sizew,
		// Token: 0x04002140 RID: 8512
		dc_sizee,
		// Token: 0x04002141 RID: 8513
		dc_sizen,
		// Token: 0x04002142 RID: 8514
		dc_sizes,
		// Token: 0x04002143 RID: 8515
		dc_sizewe,
		// Token: 0x04002144 RID: 8516
		dc_sizens,
		// Token: 0x04002145 RID: 8517
		dc_sizeall,
		// Token: 0x04002146 RID: 8518
		dc_no,
		// Token: 0x04002147 RID: 8519
		dc_hand,
		// Token: 0x04002148 RID: 8520
		dc_blank,
		// Token: 0x04002149 RID: 8521
		dc_middle_pan,
		// Token: 0x0400214A RID: 8522
		dc_north_pan,
		// Token: 0x0400214B RID: 8523
		dc_north_east_pan,
		// Token: 0x0400214C RID: 8524
		dc_east_pan,
		// Token: 0x0400214D RID: 8525
		dc_south_east_pan,
		// Token: 0x0400214E RID: 8526
		dc_south_pan,
		// Token: 0x0400214F RID: 8527
		dc_south_west_pan,
		// Token: 0x04002150 RID: 8528
		dc_west_pan,
		// Token: 0x04002151 RID: 8529
		dc_north_west_pan,
		// Token: 0x04002152 RID: 8530
		dc_alias,
		// Token: 0x04002153 RID: 8531
		dc_cell,
		// Token: 0x04002154 RID: 8532
		dc_colresize,
		// Token: 0x04002155 RID: 8533
		dc_copycur,
		// Token: 0x04002156 RID: 8534
		dc_verticaltext,
		// Token: 0x04002157 RID: 8535
		dc_rowresize,
		// Token: 0x04002158 RID: 8536
		dc_zoomin,
		// Token: 0x04002159 RID: 8537
		dc_zoomout,
		// Token: 0x0400215A RID: 8538
		dc_help,
		// Token: 0x0400215B RID: 8539
		dc_custom,
		// Token: 0x0400215C RID: 8540
		dc_last
	}
}
