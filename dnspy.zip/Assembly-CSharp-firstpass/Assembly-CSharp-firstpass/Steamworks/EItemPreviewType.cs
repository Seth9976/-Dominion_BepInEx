﻿using System;

namespace Steamworks
{
	// Token: 0x02000273 RID: 627
	public enum EItemPreviewType
	{
		// Token: 0x040023A1 RID: 9121
		k_EItemPreviewType_Image,
		// Token: 0x040023A2 RID: 9122
		k_EItemPreviewType_YouTubeVideo,
		// Token: 0x040023A3 RID: 9123
		k_EItemPreviewType_Sketchfab,
		// Token: 0x040023A4 RID: 9124
		k_EItemPreviewType_EnvironmentMap_HorizontalCross,
		// Token: 0x040023A5 RID: 9125
		k_EItemPreviewType_EnvironmentMap_LatLong,
		// Token: 0x040023A6 RID: 9126
		k_EItemPreviewType_ReservedMax = 255
	}
}
