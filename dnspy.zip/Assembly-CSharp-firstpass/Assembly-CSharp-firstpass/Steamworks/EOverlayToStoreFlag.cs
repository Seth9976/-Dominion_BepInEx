﻿using System;

namespace Steamworks
{
	// Token: 0x02000247 RID: 583
	public enum EOverlayToStoreFlag
	{
		// Token: 0x04002112 RID: 8466
		k_EOverlayToStoreFlag_None,
		// Token: 0x04002113 RID: 8467
		k_EOverlayToStoreFlag_AddToCart,
		// Token: 0x04002114 RID: 8468
		k_EOverlayToStoreFlag_AddToCartAndShow
	}
}
