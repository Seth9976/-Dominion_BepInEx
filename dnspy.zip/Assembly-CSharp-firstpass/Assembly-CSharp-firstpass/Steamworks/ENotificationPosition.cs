﻿using System;

namespace Steamworks
{
	// Token: 0x0200028F RID: 655
	public enum ENotificationPosition
	{
		// Token: 0x040024F2 RID: 9458
		k_EPositionTopLeft,
		// Token: 0x040024F3 RID: 9459
		k_EPositionTopRight,
		// Token: 0x040024F4 RID: 9460
		k_EPositionBottomLeft,
		// Token: 0x040024F5 RID: 9461
		k_EPositionBottomRight
	}
}
