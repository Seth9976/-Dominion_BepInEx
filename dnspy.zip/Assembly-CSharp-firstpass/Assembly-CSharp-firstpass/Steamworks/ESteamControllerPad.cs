﻿using System;

namespace Steamworks
{
	// Token: 0x02000251 RID: 593
	public enum ESteamControllerPad
	{
		// Token: 0x04002298 RID: 8856
		k_ESteamControllerPad_Left,
		// Token: 0x04002299 RID: 8857
		k_ESteamControllerPad_Right
	}
}
