﻿using System;

namespace Steamworks
{
	// Token: 0x0200024B RID: 587
	public enum EHTMLMouseButton
	{
		// Token: 0x0400212F RID: 8495
		eHTMLMouseButton_Left,
		// Token: 0x04002130 RID: 8496
		eHTMLMouseButton_Right,
		// Token: 0x04002131 RID: 8497
		eHTMLMouseButton_Middle
	}
}
