﻿using System;

namespace Steamworks
{
	// Token: 0x02000264 RID: 612
	public enum ERemoteStoragePublishedFileVisibility
	{
		// Token: 0x04002319 RID: 8985
		k_ERemoteStoragePublishedFileVisibilityPublic,
		// Token: 0x0400231A RID: 8986
		k_ERemoteStoragePublishedFileVisibilityFriendsOnly,
		// Token: 0x0400231B RID: 8987
		k_ERemoteStoragePublishedFileVisibilityPrivate,
		// Token: 0x0400231C RID: 8988
		k_ERemoteStoragePublishedFileVisibilityUnlisted
	}
}
