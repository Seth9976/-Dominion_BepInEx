﻿using System;

namespace Steamworks
{
	// Token: 0x02000296 RID: 662
	public enum EDurationControlOnlineState
	{
		// Token: 0x04002566 RID: 9574
		k_EDurationControlOnlineState_Invalid,
		// Token: 0x04002567 RID: 9575
		k_EDurationControlOnlineState_Offline,
		// Token: 0x04002568 RID: 9576
		k_EDurationControlOnlineState_Online,
		// Token: 0x04002569 RID: 9577
		k_EDurationControlOnlineState_OnlineHighPri
	}
}
