﻿using System;

namespace Steamworks
{
	// Token: 0x020002A6 RID: 678
	public enum ESteamIPType
	{
		// Token: 0x0400264D RID: 9805
		k_ESteamIPTypeIPv4,
		// Token: 0x0400264E RID: 9806
		k_ESteamIPTypeIPv6
	}
}
