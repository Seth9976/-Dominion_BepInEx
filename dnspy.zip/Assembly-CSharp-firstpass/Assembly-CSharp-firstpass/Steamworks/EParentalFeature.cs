﻿using System;

namespace Steamworks
{
	// Token: 0x02000261 RID: 609
	public enum EParentalFeature
	{
		// Token: 0x040022F9 RID: 8953
		k_EFeatureInvalid,
		// Token: 0x040022FA RID: 8954
		k_EFeatureStore,
		// Token: 0x040022FB RID: 8955
		k_EFeatureCommunity,
		// Token: 0x040022FC RID: 8956
		k_EFeatureProfile,
		// Token: 0x040022FD RID: 8957
		k_EFeatureFriends,
		// Token: 0x040022FE RID: 8958
		k_EFeatureNews,
		// Token: 0x040022FF RID: 8959
		k_EFeatureTrading,
		// Token: 0x04002300 RID: 8960
		k_EFeatureSettings,
		// Token: 0x04002301 RID: 8961
		k_EFeatureConsole,
		// Token: 0x04002302 RID: 8962
		k_EFeatureBrowser,
		// Token: 0x04002303 RID: 8963
		k_EFeatureParentalSetup,
		// Token: 0x04002304 RID: 8964
		k_EFeatureLibrary,
		// Token: 0x04002305 RID: 8965
		k_EFeatureTest,
		// Token: 0x04002306 RID: 8966
		k_EFeatureSiteLicense,
		// Token: 0x04002307 RID: 8967
		k_EFeatureMax
	}
}
