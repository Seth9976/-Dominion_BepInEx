﻿using System;

namespace Steamworks
{
	// Token: 0x02000256 RID: 598
	public enum ELobbyComparison
	{
		// Token: 0x040022B8 RID: 8888
		k_ELobbyComparisonEqualToOrLessThan = -2,
		// Token: 0x040022B9 RID: 8889
		k_ELobbyComparisonLessThan,
		// Token: 0x040022BA RID: 8890
		k_ELobbyComparisonEqual,
		// Token: 0x040022BB RID: 8891
		k_ELobbyComparisonGreaterThan,
		// Token: 0x040022BC RID: 8892
		k_ELobbyComparisonEqualToOrGreaterThan,
		// Token: 0x040022BD RID: 8893
		k_ELobbyComparisonNotEqual
	}
}
