﻿using System;

namespace Steamworks
{
	// Token: 0x02000298 RID: 664
	public enum EPlayerResult_t
	{
		// Token: 0x04002575 RID: 9589
		k_EPlayerResultFailedToConnect = 1,
		// Token: 0x04002576 RID: 9590
		k_EPlayerResultAbandoned,
		// Token: 0x04002577 RID: 9591
		k_EPlayerResultKicked,
		// Token: 0x04002578 RID: 9592
		k_EPlayerResultIncomplete,
		// Token: 0x04002579 RID: 9593
		k_EPlayerResultCompleted
	}
}
