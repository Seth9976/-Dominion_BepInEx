﻿using System;

namespace Steamworks
{
	// Token: 0x02000275 RID: 629
	public enum ELeaderboardDataRequest
	{
		// Token: 0x040023AB RID: 9131
		k_ELeaderboardDataRequestGlobal,
		// Token: 0x040023AC RID: 9132
		k_ELeaderboardDataRequestGlobalAroundUser,
		// Token: 0x040023AD RID: 9133
		k_ELeaderboardDataRequestFriends,
		// Token: 0x040023AE RID: 9134
		k_ELeaderboardDataRequestUsers
	}
}
