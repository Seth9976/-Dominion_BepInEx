﻿using System;

namespace Steamworks
{
	// Token: 0x02000248 RID: 584
	public enum EActivateGameOverlayToWebPageMode
	{
		// Token: 0x04002116 RID: 8470
		k_EActivateGameOverlayToWebPageMode_Default,
		// Token: 0x04002117 RID: 8471
		k_EActivateGameOverlayToWebPageMode_Modal
	}
}
