﻿using System;

namespace Steamworks
{
	// Token: 0x0200025E RID: 606
	public enum EP2PSend
	{
		// Token: 0x040022E4 RID: 8932
		k_EP2PSendUnreliable,
		// Token: 0x040022E5 RID: 8933
		k_EP2PSendUnreliableNoDelay,
		// Token: 0x040022E6 RID: 8934
		k_EP2PSendReliable,
		// Token: 0x040022E7 RID: 8935
		k_EP2PSendReliableWithBuffering
	}
}
