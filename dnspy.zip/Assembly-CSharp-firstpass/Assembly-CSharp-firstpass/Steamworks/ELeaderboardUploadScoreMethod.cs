﻿using System;

namespace Steamworks
{
	// Token: 0x02000278 RID: 632
	public enum ELeaderboardUploadScoreMethod
	{
		// Token: 0x040023B9 RID: 9145
		k_ELeaderboardUploadScoreMethodNone,
		// Token: 0x040023BA RID: 9146
		k_ELeaderboardUploadScoreMethodKeepBest,
		// Token: 0x040023BB RID: 9147
		k_ELeaderboardUploadScoreMethodForceUpdate
	}
}
