﻿using System;

namespace Steamworks
{
	// Token: 0x0200027E RID: 638
	public enum EMatchMakingServerResponse
	{
		// Token: 0x040023D4 RID: 9172
		eServerResponded,
		// Token: 0x040023D5 RID: 9173
		eServerFailedToRespond,
		// Token: 0x040023D6 RID: 9174
		eNoServersListedOnMasterServer
	}
}
