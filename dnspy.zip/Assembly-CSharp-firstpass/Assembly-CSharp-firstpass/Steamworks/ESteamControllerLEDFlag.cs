﻿using System;

namespace Steamworks
{
	// Token: 0x02000242 RID: 578
	public enum ESteamControllerLEDFlag
	{
		// Token: 0x040020E5 RID: 8421
		k_ESteamControllerLEDFlag_SetColor,
		// Token: 0x040020E6 RID: 8422
		k_ESteamControllerLEDFlag_RestoreUserDefault
	}
}
