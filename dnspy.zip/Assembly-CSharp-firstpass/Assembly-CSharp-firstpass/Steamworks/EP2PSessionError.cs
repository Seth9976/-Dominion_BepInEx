﻿using System;

namespace Steamworks
{
	// Token: 0x0200025D RID: 605
	public enum EP2PSessionError
	{
		// Token: 0x040022DD RID: 8925
		k_EP2PSessionErrorNone,
		// Token: 0x040022DE RID: 8926
		k_EP2PSessionErrorNotRunningApp,
		// Token: 0x040022DF RID: 8927
		k_EP2PSessionErrorNoRightsToApp,
		// Token: 0x040022E0 RID: 8928
		k_EP2PSessionErrorDestinationNotLoggedIn,
		// Token: 0x040022E1 RID: 8929
		k_EP2PSessionErrorTimeout,
		// Token: 0x040022E2 RID: 8930
		k_EP2PSessionErrorMax
	}
}
