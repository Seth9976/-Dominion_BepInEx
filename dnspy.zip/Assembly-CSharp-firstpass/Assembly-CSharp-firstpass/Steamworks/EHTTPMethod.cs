﻿using System;

namespace Steamworks
{
	// Token: 0x0200029B RID: 667
	public enum EHTTPMethod
	{
		// Token: 0x04002583 RID: 9603
		k_EHTTPMethodInvalid,
		// Token: 0x04002584 RID: 9604
		k_EHTTPMethodGET,
		// Token: 0x04002585 RID: 9605
		k_EHTTPMethodHEAD,
		// Token: 0x04002586 RID: 9606
		k_EHTTPMethodPOST,
		// Token: 0x04002587 RID: 9607
		k_EHTTPMethodPUT,
		// Token: 0x04002588 RID: 9608
		k_EHTTPMethodDELETE,
		// Token: 0x04002589 RID: 9609
		k_EHTTPMethodOPTIONS,
		// Token: 0x0400258A RID: 9610
		k_EHTTPMethodPATCH
	}
}
