﻿using System;

namespace Steamworks
{
	// Token: 0x0200024D RID: 589
	[Flags]
	public enum EHTMLKeyModifiers
	{
		// Token: 0x0400215E RID: 8542
		k_eHTMLKeyModifier_None = 0,
		// Token: 0x0400215F RID: 8543
		k_eHTMLKeyModifier_AltDown = 1,
		// Token: 0x04002160 RID: 8544
		k_eHTMLKeyModifier_CtrlDown = 2,
		// Token: 0x04002161 RID: 8545
		k_eHTMLKeyModifier_ShiftDown = 4
	}
}
