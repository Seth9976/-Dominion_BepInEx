﻿using System;

namespace Steamworks
{
	// Token: 0x02000276 RID: 630
	public enum ELeaderboardSortMethod
	{
		// Token: 0x040023B0 RID: 9136
		k_ELeaderboardSortMethodNone,
		// Token: 0x040023B1 RID: 9137
		k_ELeaderboardSortMethodAscending,
		// Token: 0x040023B2 RID: 9138
		k_ELeaderboardSortMethodDescending
	}
}
