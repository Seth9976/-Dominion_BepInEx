﻿using System;

namespace Steamworks
{
	// Token: 0x02000299 RID: 665
	public enum ESteamIPv6ConnectivityProtocol
	{
		// Token: 0x0400257B RID: 9595
		k_ESteamIPv6ConnectivityProtocol_Invalid,
		// Token: 0x0400257C RID: 9596
		k_ESteamIPv6ConnectivityProtocol_HTTP,
		// Token: 0x0400257D RID: 9597
		k_ESteamIPv6ConnectivityProtocol_UDP
	}
}
