﻿using System;

namespace Steamworks
{
	// Token: 0x0200027A RID: 634
	public enum EGamepadTextInputMode
	{
		// Token: 0x040023C3 RID: 9155
		k_EGamepadTextInputModeNormal,
		// Token: 0x040023C4 RID: 9156
		k_EGamepadTextInputModePassword
	}
}
