﻿using System;

namespace Steamworks
{
	// Token: 0x02000294 RID: 660
	public enum EDurationControlProgress
	{
		// Token: 0x04002556 RID: 9558
		k_EDurationControlProgress_Full,
		// Token: 0x04002557 RID: 9559
		k_EDurationControlProgress_Half,
		// Token: 0x04002558 RID: 9560
		k_EDurationControlProgress_None,
		// Token: 0x04002559 RID: 9561
		k_EDurationControl_ExitSoon_3h,
		// Token: 0x0400255A RID: 9562
		k_EDurationControl_ExitSoon_5h,
		// Token: 0x0400255B RID: 9563
		k_EDurationControl_ExitSoon_Night
	}
}
