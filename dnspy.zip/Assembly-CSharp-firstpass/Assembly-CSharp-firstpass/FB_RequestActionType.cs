﻿using System;

// Token: 0x02000089 RID: 137
public enum FB_RequestActionType
{
	// Token: 0x040007A1 RID: 1953
	Send,
	// Token: 0x040007A2 RID: 1954
	AskFor,
	// Token: 0x040007A3 RID: 1955
	Turn,
	// Token: 0x040007A4 RID: 1956
	Undefined
}
