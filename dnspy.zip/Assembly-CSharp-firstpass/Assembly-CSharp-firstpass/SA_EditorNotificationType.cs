﻿using System;

// Token: 0x02000142 RID: 322
public enum SA_EditorNotificationType
{
	// Token: 0x04001203 RID: 4611
	Message,
	// Token: 0x04001204 RID: 4612
	Achievement,
	// Token: 0x04001205 RID: 4613
	Leaderboards,
	// Token: 0x04001206 RID: 4614
	Error
}
