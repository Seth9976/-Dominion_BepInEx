﻿using System;

// Token: 0x02000007 RID: 7
public enum AN_SoomlaSocialProvider
{
	// Token: 0x04000044 RID: 68
	FACEBOOK = 1,
	// Token: 0x04000045 RID: 69
	TWITTER,
	// Token: 0x04000046 RID: 70
	GOOGLE,
	// Token: 0x04000047 RID: 71
	INSTAGRAM
}
