﻿using System;

// Token: 0x02000026 RID: 38
public enum AN_PlusBtnSize
{
	// Token: 0x0400030B RID: 779
	SIZE_SMALL,
	// Token: 0x0400030C RID: 780
	SIZE_MEDIUM,
	// Token: 0x0400030D RID: 781
	SIZE_TALL,
	// Token: 0x0400030E RID: 782
	SIZE_STANDARD
}
