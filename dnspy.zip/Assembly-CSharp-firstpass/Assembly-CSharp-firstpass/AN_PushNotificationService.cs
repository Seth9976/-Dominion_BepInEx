﻿using System;

// Token: 0x020000D4 RID: 212
public enum AN_PushNotificationService
{
	// Token: 0x04000BBD RID: 3005
	Google,
	// Token: 0x04000BBE RID: 3006
	OneSignal,
	// Token: 0x04000BBF RID: 3007
	Parse
}
