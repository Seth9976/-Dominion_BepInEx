﻿using System;

// Token: 0x02000088 RID: 136
public enum FB_PermissionStatus
{
	// Token: 0x0400079E RID: 1950
	Granted,
	// Token: 0x0400079F RID: 1951
	Declined
}
