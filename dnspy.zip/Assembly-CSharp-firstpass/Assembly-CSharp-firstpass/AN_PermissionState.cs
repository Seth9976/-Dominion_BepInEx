﻿using System;

// Token: 0x020000D3 RID: 211
public enum AN_PermissionState
{
	// Token: 0x04000BBA RID: 3002
	PERMISSION_GRANTED,
	// Token: 0x04000BBB RID: 3003
	PERMISSION_DENIED = -1
}
