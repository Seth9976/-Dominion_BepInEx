﻿using System;

// Token: 0x02000059 RID: 89
public enum GP_QuestSortOrder
{
	// Token: 0x04000589 RID: 1417
	SORT_ORDER_RECENTLY_UPDATED_FIRST,
	// Token: 0x0400058A RID: 1418
	SORT_ORDER_ENDING_SOON_FIRST
}
