﻿using System;

// Token: 0x02000086 RID: 134
public enum FB_Gender
{
	// Token: 0x04000797 RID: 1943
	Male = 1,
	// Token: 0x04000798 RID: 1944
	Female
}
