﻿using System;

// Token: 0x02000085 RID: 133
public enum FB_AppRequestState
{
	// Token: 0x04000794 RID: 1940
	Pending,
	// Token: 0x04000795 RID: 1941
	Deleted
}
