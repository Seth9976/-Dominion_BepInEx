﻿using System;

// Token: 0x02000018 RID: 24
public enum GooglePurchaseState
{
	// Token: 0x040001D5 RID: 469
	PURCHASED,
	// Token: 0x040001D6 RID: 470
	CANCELED,
	// Token: 0x040001D7 RID: 471
	REFUNDED
}
