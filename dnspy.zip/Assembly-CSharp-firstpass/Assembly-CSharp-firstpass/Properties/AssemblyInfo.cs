﻿using System;
using System.Reflection;
using System.Runtime.Versioning;

[assembly: AssemblyAlgorithmId(0)]
[assembly: AssemblyVersion("1.4.0.0")]
