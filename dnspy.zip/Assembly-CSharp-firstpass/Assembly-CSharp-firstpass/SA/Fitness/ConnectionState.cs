﻿using System;

namespace SA.Fitness
{
	// Token: 0x0200032D RID: 813
	public enum ConnectionState
	{
		// Token: 0x04002DB4 RID: 11700
		CONNECTED,
		// Token: 0x04002DB5 RID: 11701
		CONNECTING,
		// Token: 0x04002DB6 RID: 11702
		DISCONNECTED
	}
}
