﻿using System;

namespace SA.Fitness
{
	// Token: 0x0200032E RID: 814
	public enum DataSourceType
	{
		// Token: 0x04002DB8 RID: 11704
		RAW,
		// Token: 0x04002DB9 RID: 11705
		DERIVED
	}
}
