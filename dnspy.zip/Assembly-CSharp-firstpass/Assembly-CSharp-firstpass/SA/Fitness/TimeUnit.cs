﻿using System;

namespace SA.Fitness
{
	// Token: 0x0200032F RID: 815
	public enum TimeUnit
	{
		// Token: 0x04002DBB RID: 11707
		Days,
		// Token: 0x04002DBC RID: 11708
		Hours,
		// Token: 0x04002DBD RID: 11709
		Microseconds,
		// Token: 0x04002DBE RID: 11710
		Milliseconds,
		// Token: 0x04002DBF RID: 11711
		Nanoseconds,
		// Token: 0x04002DC0 RID: 11712
		Seconds
	}
}
