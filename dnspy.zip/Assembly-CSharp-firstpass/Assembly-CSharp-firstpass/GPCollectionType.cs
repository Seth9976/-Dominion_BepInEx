﻿using System;

// Token: 0x02000039 RID: 57
public enum GPCollectionType
{
	// Token: 0x0400042E RID: 1070
	GLOBAL,
	// Token: 0x0400042F RID: 1071
	FRIENDS
}
