﻿using System;

// Token: 0x02000041 RID: 65
public enum GP_InvitationType
{
	// Token: 0x04000493 RID: 1171
	INVITATION_TYPE_REAL_TIME,
	// Token: 0x04000494 RID: 1172
	INVITATION_TYPE_TURN_BASED
}
