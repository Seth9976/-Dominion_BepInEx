﻿using System;

// Token: 0x0200007F RID: 127
public enum AndroidDialogResult
{
	// Token: 0x04000756 RID: 1878
	YES,
	// Token: 0x04000757 RID: 1879
	NO,
	// Token: 0x04000758 RID: 1880
	RATED,
	// Token: 0x04000759 RID: 1881
	REMIND,
	// Token: 0x0400075A RID: 1882
	DECLINED,
	// Token: 0x0400075B RID: 1883
	CLOSED
}
