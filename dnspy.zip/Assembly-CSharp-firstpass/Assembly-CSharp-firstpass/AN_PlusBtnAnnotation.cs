﻿using System;

// Token: 0x02000025 RID: 37
public enum AN_PlusBtnAnnotation
{
	// Token: 0x04000307 RID: 775
	ANNOTATION_NONE,
	// Token: 0x04000308 RID: 776
	ANNOTATION_BUBBLE,
	// Token: 0x04000309 RID: 777
	ANNOTATION_INLINE
}
