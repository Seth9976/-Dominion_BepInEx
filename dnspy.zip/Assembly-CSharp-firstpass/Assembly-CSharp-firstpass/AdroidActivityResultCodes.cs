﻿using System;

// Token: 0x02000035 RID: 53
public enum AdroidActivityResultCodes
{
	// Token: 0x0400041F RID: 1055
	RESULT_OK = -1,
	// Token: 0x04000420 RID: 1056
	RESULT_CANCELED,
	// Token: 0x04000421 RID: 1057
	RESULT_FIRST_USER
}
