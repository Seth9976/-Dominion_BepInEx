﻿using System;

// Token: 0x0200000C RID: 12
public enum GADBannerSize
{
	// Token: 0x040000C4 RID: 196
	BANNER = 1,
	// Token: 0x040000C5 RID: 197
	SMART_BANNER,
	// Token: 0x040000C6 RID: 198
	FULL_BANNER,
	// Token: 0x040000C7 RID: 199
	LEADERBOARD,
	// Token: 0x040000C8 RID: 200
	MEDIUM_RECTANGLE
}
