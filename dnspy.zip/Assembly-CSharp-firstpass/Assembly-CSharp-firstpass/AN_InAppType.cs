﻿using System;

// Token: 0x02000016 RID: 22
public enum AN_InAppType
{
	// Token: 0x040001BD RID: 445
	Consumable,
	// Token: 0x040001BE RID: 446
	NonConsumable,
	// Token: 0x040001BF RID: 447
	Subscription
}
