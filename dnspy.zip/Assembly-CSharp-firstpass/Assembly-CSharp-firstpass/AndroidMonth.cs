﻿using System;

// Token: 0x0200000B RID: 11
public enum AndroidMonth
{
	// Token: 0x040000B7 RID: 183
	JANUARY,
	// Token: 0x040000B8 RID: 184
	FEBRUARY,
	// Token: 0x040000B9 RID: 185
	MARCH,
	// Token: 0x040000BA RID: 186
	APRIL,
	// Token: 0x040000BB RID: 187
	MAY,
	// Token: 0x040000BC RID: 188
	JUNE,
	// Token: 0x040000BD RID: 189
	JULY,
	// Token: 0x040000BE RID: 190
	AUGUST,
	// Token: 0x040000BF RID: 191
	SEPTEMBER,
	// Token: 0x040000C0 RID: 192
	OCTOBER,
	// Token: 0x040000C1 RID: 193
	NOVEMBER,
	// Token: 0x040000C2 RID: 194
	DECEMBER
}
