﻿using System;

// Token: 0x02000061 RID: 97
public enum GP_RTM_PackageType
{
	// Token: 0x040005D6 RID: 1494
	RELIABLE,
	// Token: 0x040005D7 RID: 1495
	UNRELIABLE
}
