﻿using System;

// Token: 0x02000060 RID: 96
public enum GP_RTM_MessageType
{
	// Token: 0x040005D3 RID: 1491
	Reliable,
	// Token: 0x040005D4 RID: 1492
	Unreliable
}
