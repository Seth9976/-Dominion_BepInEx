﻿using System;

// Token: 0x02000080 RID: 128
public enum AndroidDialogTheme
{
	// Token: 0x0400075D RID: 1885
	ThemeDeviceDefaultDark,
	// Token: 0x0400075E RID: 1886
	ThemeDeviceDefaultLight,
	// Token: 0x0400075F RID: 1887
	ThemeHoloDark,
	// Token: 0x04000760 RID: 1888
	ThemeHoloLight,
	// Token: 0x04000761 RID: 1889
	ThemeTraditional
}
