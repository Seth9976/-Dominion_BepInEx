﻿using System;

// Token: 0x02000036 RID: 54
public enum GPAchievementState
{
	// Token: 0x04000423 RID: 1059
	STATE_UNLOCKED,
	// Token: 0x04000424 RID: 1060
	STATE_REVEALED,
	// Token: 0x04000425 RID: 1061
	STATE_HIDDEN
}
