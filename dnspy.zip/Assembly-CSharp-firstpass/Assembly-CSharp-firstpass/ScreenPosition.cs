﻿using System;

// Token: 0x02000106 RID: 262
public enum ScreenPosition
{
	// Token: 0x04000DD8 RID: 3544
	UpperLeft,
	// Token: 0x04000DD9 RID: 3545
	UpperMiddle,
	// Token: 0x04000DDA RID: 3546
	UpperRight,
	// Token: 0x04000DDB RID: 3547
	Left,
	// Token: 0x04000DDC RID: 3548
	Middle,
	// Token: 0x04000DDD RID: 3549
	Right,
	// Token: 0x04000DDE RID: 3550
	LowerLeft,
	// Token: 0x04000DDF RID: 3551
	LowerMiddle,
	// Token: 0x04000DE0 RID: 3552
	LowerRight
}
