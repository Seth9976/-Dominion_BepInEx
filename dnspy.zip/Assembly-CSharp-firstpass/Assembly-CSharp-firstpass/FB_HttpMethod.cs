﻿using System;

// Token: 0x02000087 RID: 135
public enum FB_HttpMethod
{
	// Token: 0x0400079A RID: 1946
	GET,
	// Token: 0x0400079B RID: 1947
	POST,
	// Token: 0x0400079C RID: 1948
	DELETE
}
