﻿using System;

// Token: 0x020000CE RID: 206
public enum AN_LicenseStatusCode
{
	// Token: 0x04000B67 RID: 2919
	RESULT_ALLOW,
	// Token: 0x04000B68 RID: 2920
	RESULT_DONTALLOW,
	// Token: 0x04000B69 RID: 2921
	RESULT_ERROR
}
