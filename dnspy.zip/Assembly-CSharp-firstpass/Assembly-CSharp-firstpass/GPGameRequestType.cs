﻿using System;

// Token: 0x0200003B RID: 59
public enum GPGameRequestType
{
	// Token: 0x04000436 RID: 1078
	TYPE_GIFT = 1,
	// Token: 0x04000437 RID: 1079
	TYPE_WISH
}
