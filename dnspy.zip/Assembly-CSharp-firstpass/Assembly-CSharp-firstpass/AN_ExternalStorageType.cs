﻿using System;

// Token: 0x020000D0 RID: 208
public enum AN_ExternalStorageType
{
	// Token: 0x04000B6E RID: 2926
	Music,
	// Token: 0x04000B6F RID: 2927
	Podcasts,
	// Token: 0x04000B70 RID: 2928
	Ringtones,
	// Token: 0x04000B71 RID: 2929
	Alarms,
	// Token: 0x04000B72 RID: 2930
	Notifications,
	// Token: 0x04000B73 RID: 2931
	Pictures,
	// Token: 0x04000B74 RID: 2932
	Movies,
	// Token: 0x04000B75 RID: 2933
	Download,
	// Token: 0x04000B76 RID: 2934
	DCIM,
	// Token: 0x04000B77 RID: 2935
	Documents
}
