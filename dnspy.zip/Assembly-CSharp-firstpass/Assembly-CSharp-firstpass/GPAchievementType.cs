﻿using System;

// Token: 0x02000037 RID: 55
public enum GPAchievementType
{
	// Token: 0x04000427 RID: 1063
	TYPE_STANDARD,
	// Token: 0x04000428 RID: 1064
	TYPE_INCREMENTAL
}
