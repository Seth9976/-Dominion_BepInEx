﻿using System;

// Token: 0x020000D9 RID: 217
public enum AndroidCameraImageFormat
{
	// Token: 0x04000C31 RID: 3121
	JPG,
	// Token: 0x04000C32 RID: 3122
	PNG
}
