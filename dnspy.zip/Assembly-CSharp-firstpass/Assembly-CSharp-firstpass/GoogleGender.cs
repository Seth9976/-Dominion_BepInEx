﻿using System;

// Token: 0x0200000E RID: 14
public enum GoogleGender
{
	// Token: 0x040000CF RID: 207
	Unknown,
	// Token: 0x040000D0 RID: 208
	Male,
	// Token: 0x040000D1 RID: 209
	Female
}
