﻿using System;

// Token: 0x02000038 RID: 56
public enum GPBoardTimeSpan
{
	// Token: 0x0400042A RID: 1066
	ALL_TIME = 2,
	// Token: 0x0400042B RID: 1067
	WEEK = 1,
	// Token: 0x0400042C RID: 1068
	TODAY = 0
}
