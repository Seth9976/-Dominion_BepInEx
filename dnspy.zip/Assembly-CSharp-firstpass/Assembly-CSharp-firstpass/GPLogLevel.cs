﻿using System;

// Token: 0x0200003C RID: 60
public enum GPLogLevel
{
	// Token: 0x04000439 RID: 1081
	VERBOSE,
	// Token: 0x0400043A RID: 1082
	INFO,
	// Token: 0x0400043B RID: 1083
	WARNING,
	// Token: 0x0400043C RID: 1084
	ERROR
}
