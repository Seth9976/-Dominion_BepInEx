﻿using System;

// Token: 0x02000004 RID: 4
public enum AN_SoomlaEventType
{
	// Token: 0x04000009 RID: 9
	SOOMLA_EVENT_STARTED = 1,
	// Token: 0x0400000A RID: 10
	SOOMLA_EVENT_FINISHED,
	// Token: 0x0400000B RID: 11
	SOOMLA_EVENT_CNACELED,
	// Token: 0x0400000C RID: 12
	SOOMLA_EVENT_FAILED
}
