﻿using System;

// Token: 0x0200000F RID: 15
[Flags]
public enum GoogleGravity
{
	// Token: 0x040000D3 RID: 211
	BOTTOM = 80,
	// Token: 0x040000D4 RID: 212
	CENTER = 17,
	// Token: 0x040000D5 RID: 213
	RIGHT = 5,
	// Token: 0x040000D6 RID: 214
	LEFT = 3,
	// Token: 0x040000D7 RID: 215
	TOP = 48
}
